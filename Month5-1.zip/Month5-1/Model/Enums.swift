import Foundation
import UIKit

enum Constants {
    enum urlPaths {
    static let allCategoriesUrl = URL(
        string: "https://dummyjson.com/products/categories")!
    static let productUrl = URL(
        string: "https://dummyjson.com/products")!
    }
    
    enum reuseId {
        static let collectionViewId = "CategoryCollectionViewCell"
        static let subCollectionViewID = "SubCategoriesCollectionViewCell"
        static let tableViewId = ""
    }
}

import UIKit
import SnapKit

class ViewController: UIViewController {
    
    var categories: [Categories] = []
    var subCategories: [SubCategories] = []
    let products: [Products] = []
    
    private lazy var categoryCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 4.0
        layout.minimumInteritemSpacing = 4.0
        layout.estimatedItemSize = CGSize(width: 80, height: 40)
        layout.scrollDirection = .horizontal
        
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.register(CategoryCollectionViewCell.self, forCellWithReuseIdentifier: Constants.reuseId.collectionViewId)
        collectionView.dataSource = self
        collectionView.delegate = self
        return collectionView
    }()
    
    private let searchBar: UISearchBar = {
      let searсhBar = UISearchBar()
        searсhBar.placeholder = "Find store by name"
        return searсhBar
    }()
    
    private lazy var subcategoryCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 4.0
        layout.minimumInteritemSpacing = 4.0
        layout.scrollDirection = .horizontal
        layout.estimatedItemSize = CGSize(width: 80, height: 40)
        let collectionView2 = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView2.register(SubCategoriesCollectionViewCell.self, forCellWithReuseIdentifier: Constants.reuseId.subCollectionViewID)
        collectionView2.dataSource = self
        collectionView2.delegate = self
        return collectionView2
    }()
    
    private let tableView: UITableView = {
        let tableView = UITableView()
        tableView.backgroundColor = .cyan
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupSubviews()
        
        categories = [Categories(categoriesTitle: "Delivery"), Categories(categoriesTitle: "Pick up"), Categories(categoriesTitle: "Catering"), Categories(categoriesTitle: "Carbside")]
        
        subCategories = [SubCategories(subcategoriesImage: "Takeaways", subCategoriesTitle: "takeaways"), SubCategories(subcategoriesImage: "Grocery", subCategoriesTitle: "grocery"), SubCategories(subcategoriesImage: "Grocery", subCategoriesTitle: "Grocery"),SubCategories(subcategoriesImage: "Grocery", subCategoriesTitle: "Grocery"),SubCategories(subcategoriesImage: "Grocery", subCategoriesTitle: "Grocery")]
        
    }
    
    func setupSubviews() {
        view.addSubview(categoryCollectionView)
        view.addSubview(searchBar)
        view.addSubview(subcategoryCollectionView)
        view.addSubview(tableView)
        
        categoryCollectionView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(40)
            make.left.right.equalToSuperview().inset(12)
            make.height.equalTo(100)
        }
        
        searchBar.snp.makeConstraints { make in
            make.top.equalTo(categoryCollectionView.snp.bottom).offset(40)
            make.left.right.equalToSuperview().inset(12)
            make.height.equalTo(44)
        }
        
        subcategoryCollectionView.snp.makeConstraints { make in
            make.top.equalTo(searchBar.snp.bottom).offset(28)
            make.left.right.equalToSuperview().inset(12)
        }
        
        tableView.snp.makeConstraints { make in
            make.top.equalTo(subcategoryCollectionView.snp.bottom)
            make.left.right.equalToSuperview().inset(12)
        }
    }
}

extension ViewController: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == self.categoryCollectionView {
            return categories.count
        }
        
        return subCategories.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: Constants.reuseId.collectionViewId, for: indexPath) as! CategoryCollectionViewCell
        cell.initData(model: categories[indexPath.row])
        if collectionView == self.categoryCollectionView {
            let cell2 = collectionView.dequeueReusableCell(withReuseIdentifier: Constants.reuseId.subCollectionViewID, for: indexPath) as! SubCategoriesCollectionViewCell
            cell2.initCell(model: subCategories[indexPath.row])
            return cell2
        }
        return cell
    }
}


extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        products.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

    }


    }

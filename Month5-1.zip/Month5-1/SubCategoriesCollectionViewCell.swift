//
//  SubCategoriesCollectionViewCell.swift
//  Month5-1
//
//  Created by Sonun on 16/5/23.
//

import UIKit

class SubCategoriesCollectionViewCell: UICollectionViewCell {
    
    private let subCategoryImage: UIImageView = {
        let image = UIImageView()
        image.layer.cornerRadius = 48/2
        return image
    }()
    
    private let imageTitle: UILabel = {
        let title = UILabel()
        title.font = .systemFont(ofSize: 12)
        return title
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupSubViews() {
        contentView.addSubview(subCategoryImage)
        contentView.addSubview(imageTitle)
        
        subCategoryImage.snp.makeConstraints { make in
            make.top.equalToSuperview()
        }
        
        imageTitle.snp.makeConstraints { make in
            make.top.equalTo(subCategoryImage.snp.bottom).offset(16)
            make.centerX.equalToSuperview()
        }
    }
    
    func initCell(model: SubCategories) {
        subCategoryImage.image = UIImage(named: model.subcategoriesImage)
        imageTitle.text = model.subCategoriesTitle
        
    }
}

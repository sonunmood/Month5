import Foundation
import UIKit

let session = URLSession.shared

//struct NetworkManager {
//    enum HTTPMethods: String {
//        case GET, POST, PUT
//    }
    
//    func fetchCategories(completion: @escaping (Result<String, Error>) -> Void
//    ) {
//        var request = URLRequest(url: Constants.urlPaths.allCategoriesUrl)
//        request.httpMethod = HTTPMethods.GET.rawValue
//        session.dataTask(with: request)
//        { data, response, error in
//            if let error {
//                completion(.failure(error))
//            }
//
//            guard let data else {
//                return
//            }
//            let decoder = JSONDecoder()
//            do {
//                let data = try decoder.decode(
//                    AllCategories.self,
//                    from: data)
//                completion(
//                    .success(
//                    data.categories))
//            } catch {
//                completion(.failure(error))
//            }
//        }
//        .resume()
//    }
//}
//
//func fetch() {
//    NetworkManager().fetchCategories { result in
//        switch result {
//        case .success(let categories):
//            print("Categories count is: \(categories.count)")
//        case .failure(let error):
//            print("Error is: \(error.localizedDescription)")
//        }
//    }
//}
